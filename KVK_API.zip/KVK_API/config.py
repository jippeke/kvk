# KVK API Configuratie
API_KEY = "l7xx1f2691f2520d487b902f4e0b57a0b197"

# LET OP: U bent zelf verantwoordelijk voor het vernieuwen van de certificaten
# en het tijdig doorgeven van de public key(s) aan de KVK. 